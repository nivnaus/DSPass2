Readme for DSP assignment 2 – Olga Oznovich 212969315 olgaoz@post.bgu.ac.il , Niv Naus 316197227 nausn@post.bgu.ac.il  

 

How to run the program: 

Set the relevant credentials in .aws/credentials 

Make sure the bucket nivolarule29122024 exists 

Make sure the following files don’t exist:  
s3://nivolarule29122024/subSums.txt 
s3://nivolarule29122024/constsW3.txt 
s3://nivolarule29122024/constsW2.txt 
s3://nivolarule29122024/notSortedOutput 
s3://nivolarule29122024/output 
s3://nivolarule29122024/c0.txt 

Run Step1/App.java -> runs the cluster 

Have faith and patience :) 

 

Our programs consist of 5 steps: 

Step 1 – receives the 3-grams, and outputs all the sub-grams needed for the calculation (N1,N2..). the subs are for a 3gram w1 w2 w3:  
w1 w2 w3 -> for counting N3
* * * -> for counting C0 - the amount of all the words 
w1 w2 * -> for counting C2
* w2 * -> for counting C1
* w2 w3 -> for counting N2
* * w3 -> for counting N1
 

Mapper: receives a 3-gram record and extracts w1 w2 w3 and match count. Emits all the subs with the relevant count. 

Partitioner: default.  

Reducer: receives every sub (for example “ * הלך *”) and all the counts across mappers (for example: [20, 8, 13]). Emits the sub with the sum to the file subSums. 
C0 is uploaded to s3 to a file “c0.txt” so it can be shared with the next step. 
 

Step 2 – Receives the subs and sums from subSums, and emits the trio its connected to with the constant and its value. For example, “ילד הלך לגן” C2 34. It will be the same for C0, C1, C2, N2, N3. 

C0 is downloaded from s3. 

Mapper: nothing special 

Partitioner: categorizes according to w2.hashcode 

Reducer: gathers all constants but N1, to output file constsW2 

 

Step 3 – Receives the subs and sums from subSums, and emits the trio its connected to with the constant and its value. For example
, “ילד הלך לגן” N1 34. 

Mapper: nothing special 

Partitioner: categorizes according to w3.hashcode 

Reducer: gathers the constant N1, to output file constsW3 

 

Step 4 – Receives as input constsW3 and constsW2 and outputs every 3-gram record with the calculated probability according to the given formula. 

Mapper: maps all the lines with constants to the same trio key 

Partitioner: categorizes according to the trio 

Reducer: parses all the constants from the values array and calculates the formula and emits the trio with the probability. 



Step 5 – Receives as input notSortedOutput and outputs every 3-gram record with the calculated probability. 

Mapper: receives a 3-gram record and extracts w1 w2 w3 and the probability.
setting a WritableComparable object we added, class name:"TrioProbKey", with w1,w2,w3 and the probability
to Override the compareTo function. Emits all the TrioProbKey with an empty text.

Partitioner: categorizes according to the TrioProbKey.toString which is the Trio and the probability.

Reducer: emits the trio and the probability from the key. 



Output directory in s3:  s3://nivolarule29122024/output 

 

Reports: 

Step 1:  

Map input records=163471963
Map output records=86953788
Map output bytes=1863495241 

Step 2: 

Map input records=848168
Map output records=848168
Map output bytes=24048493 

Step 3: 

Map input records=848168
Map output records=407538
Map output bytes=12899912 

Step 4: 

Map input records=2203602
Map output records=2203602
Map output bytes=81487204 

Step 5:

Map input records=367267
Map output records=367267
Map output bytes=17250002


Scalability: 

For 3 mappers: 

8 minutes for a very small input (12 lines) 

22 minutes for the whole 3-gram 

For 5 mappers: 

6 minutes for a very small input (12 lines) 

19 minutes for the whole 3-gram 

 

 

3.  

"אתה צריך"

אתה צריך להבין	0.06
אתה צריך לעשות	0.05
אתה צריך ללכת	0.03
אתה צריך לתת	0.02
אתה צריך לבקש	0.01

 

“אתה אומר” 

אתה אומר לכך	0.06
אתה אומר שאין	0.05
אתה אומר כך	0.04
אתה אומר לעצמך	0.03
אתה אומר לעשות	0.02

 

“אני חושבת” 

אני חושבת שאני	0.1
אני חושבת שיש	0.05
אני חושבת שאתה	0.04
אני חושבת שאת	0.03
אני חושבת שכן	0.02

 

“אני חוזר” 

אני חוזר ואומר	0.33
אני חוזר בי		0.11
אני חוזר שוב		0.04
אני חוזר בתשובה	0.02
אני חוזר ומטעים	0.01

 

“יכול לשמש” 

יכול לשמש דוגמה	0.14
יכול לשמש גם	0.1
יכול לשמש מקור	0.06
יכול לשמש תחליף	0.04
יכול לשמש מופת	0.03

 

"ביום שישי” 

ביום שישי בבוקר	0.2
ביום שישי שעבר	0.06
ביום שישי בשעה	0.05
ביום שישי הקרוב	0.04
ביום שישי בשבוע	0.03 

 
 
“ביום שבת” 

ביום שבת קודש	0.61
ביום שבת קדש	0.15
ביום שבת בבוקר	0.07
ביום שבת ומועד	0.04
ביום שבת הגדול	0.02

 

“אלא שאני” 

אלא שאני אומר	0.24
אלא שאני רואה	0.12
אלא שאני הייתי	0.06
אלא שאני צריך	0.04
אלא שאני גם	0.03

 

“שנים רבות” 

שנים רבות לאחר	0.17
שנים רבות לפני	0.13
שנים רבות קודם	0.05
שנים רבות שימש	0.02
שנים רבות ישב	0.01

 

“תחת ממשלת” 

תחת ממשלת אדוננו	0.18
תחת ממשלת אדונינו	0.15
תחת ממשלת המלך	0.09
תחת ממשלת מלכי	0.08
תחת ממשלת מלך	0.07 